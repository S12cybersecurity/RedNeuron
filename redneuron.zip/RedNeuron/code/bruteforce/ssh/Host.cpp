#include <iostream>
#include <string>

using namespace std;

class Host{
    string ip;
    int port;
    string user;

    Host(string ip,int port,string user){
    }
    
};