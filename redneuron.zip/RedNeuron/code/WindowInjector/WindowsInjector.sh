#/bin/bash

bash code/WindowInjector/src/banner.sh
